from PIL import Image

def resize_image(image_path, output_path, size):
    """Изменение размера изображения."""
    with Image.open(image_path) as img:
        resized_img = img.resize(size)
        resized_img.save(output_path)
    return output_path

def rotate_image(image_path, output_path, angle):
    """Поворот изображения на заданный угол."""
    with Image.open(image_path) as img:
        rotated_img = img.rotate(angle)
        rotated_img.save(output_path)
    return output_path
