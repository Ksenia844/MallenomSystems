import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import ImageTk
import SampleModule

class ImageUtilityApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Утилита работы с изображениями, Аксёнова Ксения Максимовна")
        
        self.image_path = None
        
        self.label = tk.Label(root, text="Выбранное изображение:")
        self.label.pack()
        
        self.image_label = tk.Label(root)
        self.image_label.pack()
        
        self.load_button = tk.Button(root, text="Загрузить изображение", command=self.load_image)
        self.load_button.pack()
        
        self.resize_button = tk.Button(root, text="Изменить размер", command=self.resize_image)
        self.resize_button.pack()
        
        self.rotate_button = tk.Button(root, text="Повернуть изображение", command=self.rotate_image)
        self.rotate_button.pack()
        
        self.info_label = tk.Label(root, text="Блок информации")
        self.info_label.pack()

    def load_image(self):
        self.image_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp")])
        if self.image_path:
            img = ImageTk.PhotoImage(Image.open(self.image_path))
            self.image_label.config(image=img)
            self.image_label.image = img
            self.label.config(text=f"Выбранное изображение: {self.image_path}")

    def resize_image(self):
        if not self.image_path:
            messagebox.showerror("Ошибка", "Сначала загрузите изображение.")
            return
        new_size = (int(input("Введите новую ширину: ")), int(input("Введите новую высоту: ")))
        output_path = "resized_image.png"
        SampleModule.resize_image(self.image_path, output_path, new_size)
        messagebox.showinfo("Успех", f"Изображение изменено и сохранено как {output_path}.")

    def rotate_image(self):
        if not self.image_path:
            messagebox.showerror("Ошибка", "Сначала загрузите изображение.")
            return
        angle = int(input("Введите угол поворота: "))
        output_path = "rotated_image.png"
        SampleModule.rotate_image(self.image_path, output_path, angle)
        messagebox.showinfo("Успех", f"Изображение повернуто и сохранено как {output_path}.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageUtilityApp(root)
    root.mainloop()
